<?php

/**
 * @file
 * Contains \Drupal\content_tab\Plugin\Menu\LocalTask\ContentTabLocalTask.
 */

namespace Drupal\content_tab\Plugin\Menu\LocalTask;

use Drupal\Component\Utility\Unicode;
use Drupal\Core\Menu\LocalTaskDefault;

/**
 * Defines a local task plugin with a dynamic title.
 */
class ContentTabLocalTask extends LocalTaskDefault {

  /**
   * The mapper plugin discovery service.
   *
   * @var \Drupal\content_tab\ContentTabMapperInterface
   */
  protected $mapperManager;

  /**
   * {@inheritdoc}
   */
  public function getTitle() {
    $options = array();
    if (!empty($this->pluginDefinition['title_context'])) {
      $options['context'] = $this->pluginDefinition['title_context'];
    }

    // Take custom 'content_tab_plugin_id' plugin definition key to
    // retrieve title. We need to retrieve a runtime title (as opposed to
    // storing the title on the plugin definition for the link) because
    // it contains translated parts that we need in the runtime language.
    $type_name = Unicode::strtolower($this->mapperManager()->createInstance($this->pluginDefinition['content_tab_plugin_id'])->getTypeLabel());
    return $this->t($this->pluginDefinition['title'], array('@type_name' => $type_name), $options);
  }

  /**
   * Gets the mapper manager.
   *
   * @return \Drupal\content_tab\ContentTabMapperInterface
   *   The mapper manager.
   */
  protected function mapperManager() {
    if (!$this->mapperManager) {
      $this->mapperManager = \Drupal::service('plugin.manager.content_tab.mapper');
    }
    return $this->mapperManager;
  }

}
