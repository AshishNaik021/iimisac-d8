-- SUMMARY --

The Content tab module allows the administrator or the user with the 
appropriate permission to view the content written by a particular user
by navigating to http://example.com/user/4/content which would list all
the content written by the user with uid 4 (uid = 4 is taken as an example).
The different content types would be shown as subtabs clicking on which would
show the content written by that user of that particular type. Detailed
tutorial can be found

-- REQUIREMENTS --

None.


-- INSTALLATION --

* Install as usual, see http://drupal.org/node/70151 for further information.
