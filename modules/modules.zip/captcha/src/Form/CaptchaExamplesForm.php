<?php

/**
 * @file
 * Contains \Drupal\captcha\Form\CaptchaExamplesForm.
 */

namespace Drupal\captcha\Form;

use Drupal\Core\Url;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Displays the captcha settings form.
 */
class CaptchaExamplesForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'captcha_examples';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $module = NULL, $challenge = NULL) {
    module_load_include('inc', 'captcha', 'captcha.admin');

    $form = [];
    if ($module && $challenge) {
      // Generate 10 example challenges.
      for ($i = 0; $i < 10; $i++) {
        $form["challenge_{$i}"] = _captcha_generate_example_challenge($module, $challenge);
      }
    }
    else {
      // Generate a list with examples of the available CAPTCHA types.
      $form['info'] = [
        '#markup' => t('This page gives an overview of all available challenge types, generated with their current settings.'),
      ];
      foreach (\Drupal::moduleHandler()->getImplementations('captcha') as $mkey => $module) {
        $challenges = call_user_func_array($module . '_captcha', ['list']);

        if ($challenges) {
          foreach ($challenges as $ckey => $challenge) {
            $form["captcha_{$mkey}_{$ckey}"] = [
              '#type' => 'details',
              '#title' => t('Challenge %challenge by module %module', ['%challenge' => $challenge, '%module' => $module]),
              'challenge' => _captcha_generate_example_challenge($module, $challenge),
              'more_examples' => [
                '#markup' => \Drupal::l(t('10 more examples of this challenge.'), Url::fromRoute('captcha_examples', array('module' => $module, 'challenge' => $challenge))),
              ],
            ];
          }
        }
      }
    }

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}
